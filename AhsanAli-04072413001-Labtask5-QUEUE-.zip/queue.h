#pragma once
// linked list based implementation of queue
struct node {
	int val;
	node* link;

};
class queue {
	//declaring members
private:
	node* F;    // access  first element
	node* B;		// access last element
	int n; // store size 

public:
	//constructor
	queue() {
		n = 0;
		F = nullptr;
		B = nullptr;

	}
	~queue() {
	// release all memory memory
		while (!(F == nullptr) ) {
			node* temp;
			temp = F;
			F = temp->link;
			delete temp;
		}
	}
	void push(int v){	
		// creating memory block
		node* ptr1;
		ptr1 = new node;    //Todo:  also delete it 
		
		if (ptr1 == nullptr) {
			throw("Stack overflow");
		}
		else {
			++n;
		}
	
		if (n == 1) {
			ptr1->val = v;
			ptr1->link = B ;
			B = F = ptr1;
		}
		// for second and above values
		else {
			node* temp;
			temp = new node;
			temp->val = v;
			temp->link = nullptr;
			ptr1->link = temp;
			
		}
	}
	int front() const{ 
		if (F == nullptr) {
			throw("Stack Underflow");
		}
		else {
			return F->val;	 
		}
	}
	int back()const {
		if (B == nullptr) {
			throw("Stack Underflow");
		}
		else {
			return B->val;
		}
	}

	void pop() {
		if (F == nullptr) {
			throw("Stack underflow");
		}
		node* temp;
		temp = F;
		delete F;
		F = temp->link;
		--n;
		if (n == 1) {
			B = F;
		}
	}
	int size() const{
		return n;
	}
	bool empty() const{
		
		return n==0;
	}

};
