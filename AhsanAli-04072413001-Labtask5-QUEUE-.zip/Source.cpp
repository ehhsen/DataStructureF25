#include<iostream>
#include"queue.h"
int main() {
	queue q;

	std::cout << "hello";
	q.push(1);
	q.push(2);
	std::cout << "\nsize of queue: " << q.size();
	q.pop();

	std::cout<<"\nsize of queue: "<<q.size();
	std::cout << "\nfront value: "<<q.front();
	std::cout << "\nback value: " << q.back();
	if (q.empty()) {
		std::cout << "\nqueue is empty ";
	}
	else {
		std::cout << "\nqueue is not empty";
	}
	return 0;
}